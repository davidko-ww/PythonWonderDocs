Instructions
============

Contained inside this zip file is the "wonder" Python module for CircuitPython
6.3.0 . Simply copy the entire "wonder" directory to your CIRCUITPY/lib/
directory. More instructions can be found at: 
https://wlrc-open-docs-zopul.ondigitalocean.app
